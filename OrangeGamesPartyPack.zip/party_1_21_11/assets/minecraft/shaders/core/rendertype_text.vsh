#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    vec3 pos = Position;

    // --- OrangeGames Party HUD -----------------------------------------------------------------
    // Boss-bar glyphs carry an element id in the high bits of their Y (font ascent). Decode it and
    // re-anchor the glyph to a screen edge/centre. GUI orthographic pass only. ids 1..3 are the main
    // OrangeGames pack's ids and behave exactly as its shader does; ids >= 16 are Party's:
    //   id = 16 + layer + 4 * (anchorX + 3 * anchorY), anchor 0 = left/top, 1 = centre, 2 = right/bottom
    //   anchorY 3 = bottom, lifted above the chat by up to 130.0 (less on a screen under 400 high)
    vec2 ogUi = ceil(2.0 / abs(vec2(ProjMat[0][0], ProjMat[1][1])));
    if (pos.y >= ogUi.y && ProjMat[3].x == -1.0) {
        int ogBit = int(pos.y) >> 13;
        if (((ogBit >> 10) & 1) == 1) {
            int ogId = ogBit - 1024;
            pos.x -= floor(0.5 * ogUi.x);
            pos.y -= float((ogBit << 13) + 4105);
            vec2 ogAnchor = vec2(0.0);
            float ogLayer = 0.0;
            if (ogId >= 16) {
                int a = ogId - 16;
                int k = a >> 2;
                ogLayer = float(a & 3) * 0.25;
                int ogAy = k / 3;
                ogAnchor = vec2(float(k % 3), float(min(ogAy, 2))) * 0.5;
                if (ogAy == 3) {
                    pos.y -= clamp(ogUi.y - 270.0, 0.0, 130.0);
                }
            } else if (ogId == 2) {
                ogLayer = 1.0;
            } else if (ogId == 3) {
                ogAnchor.x = 1.0;
            }
            pos.xy += floor(ogAnchor * ogUi);
            pos.z += ogLayer;
        }
    }
    // -------------------------------------------------------------------------------------------

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}
